# spring-mongodb
How to intigrate spring boot with mongodb and insert update delete
